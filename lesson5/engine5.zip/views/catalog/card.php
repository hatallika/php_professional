 <h2>Товар</h2>

<div>
    <h3><?=$product->name?></h3>
    <img src="/images/<?=$product->image?>" width="300" alt="">
    <p><?=$product->description?></p>
    <p>price: <?=$product->price?></p>
    <button>Купить</button>
</div>
