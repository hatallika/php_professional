<?php

namespace app\engine;

use app\models\Users;

class Auth
{
    public static function get_user()
    {
        return $_SESSION['login'];
    }

    public static function isAuth()
    { // авторизован ли кто-то
        if(isset($_COOKIE['hash']) && !isset($_SESSION['login'])){
            $hash = $_COOKIE['hash'];

            $row = Users::getOneWhere('hash',$hash);
            if($row) {
                $user = $row['login'];
                if (!empty($user)){
                    $_SESSION['login'] = $user;
                    $_SESSION['id'] = $row['id'];
                }
            }
        }
        return isset($_SESSION['login']);
    }

}