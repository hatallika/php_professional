<?php

namespace app\controllers;

use app\models\Users;

class AuthController extends Controller
{

 //protected $defaultAction = 'login';

  public function actionLogin(){

     //action = "/auth/login"
     //form action='/?c=auth&a=login'

     $login = $_POST['login'];
     $pass = $_POST['pass'];
     if ($this->auth($login,$pass)) {
         if (isset($_POST['save'])) {
             $this->updateHash();
         }
     } else {
         $_SESSION['message']['login'] = 'Не верный логин и пароль';
     }
     header("Location: " . $_SERVER['HTTP_REFERER']);
     die();
 }

 public function actionLogout()
 {
     setcookie("hash", '', time() - 3600, '/');
     session_regenerate_id();
     session_destroy();
     header("Location: /");
     die();
 }

    function updateHash(){

        $hash = uniqid(rand(), true);
        $id = (int)$_SESSION['id'];
        $user = Users::getOne($id);
        $user->hash = $hash;
        $user->save();
        setcookie("hash", $hash, time() + 36000, '/');

    }

//проверка логина и пароля
    function auth($login, $pass){

        $passDB = Users::getOneWhere('login',$login);

        if (password_verify($pass,$passDB['pass'])){
            $_SESSION['login'] = $login;
            $_SESSION['id'] = $passDB['id'];
            return true;
        }
        return false;
    }

    function is_admin()
    {
        return $_SESSION['login'] == 'admin';
    }


}